<template>
  <h2>学习</h2>
  <p>1708 1725</p>
  <p>1743 1904</p>
  <p>2037 </p>
</template>

<script>
  export default {
    name: "Learn"
  }
</script>

<style scoped>

</style>
