<template>
  <h2>分类</h2>
</template>

<script>
  export default {
    name: "Home"
  }
</script>

<style scoped>

</style>
