<template>
  <div>
    <h2>我的</h2>
  </div>
</template>

<script>
  export default {
    name: "Home",
    created() {
      console.log("home created");
    },
    activated() {
      console.log("home activated");
    }
  }
</script>

<style scoped>

</style>
